# student_intro.py

name = input("Enter your name: ")
subject = input("Enter your favorite subject: ")

print("Hello " + name + "!")
print("Your favorite subject is " + subject + ". That's interesting!")
