# class_roster.py

print("===== CLASS ROSTER BUILDER =====")

print("\nSTUDENT 1:")
student1_name = input("Enter name: ")
student1_age = input("Enter age: ")
student1_major = input("Enter major: ")

print("\nSTUDENT 2:")
student2_name = input("Enter name: ")
student2_age = input("Enter age: ")
student2_major = input("Enter major: ")

print("\nSTUDENT 3:")
student3_name = input("Enter name: ")
student3_age = input("Enter age: ")
student3_major = input("Enter major: ")

print("\n===== CLASS ROSTER =====")

print("Student 1: " + student1_name + ", Age:", student1_age, ", Major:", student1_major)
print("Student 2: " + student2_name + ", Age:", student2_age, ", Major:", student2_major)
print("Student 3: " + student3_name + ", Age:", student3_age, ", Major:", student3_major)

print("\nTotal Students: 3")
print("====================")
