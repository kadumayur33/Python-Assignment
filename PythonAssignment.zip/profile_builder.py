# profile_builder.py

first_name = input("Enter first name: ")
last_name = input("Enter last name: ")
age = input("Enter age: ")
city = input("Enter city: ")
hobby = input("Enter hobby: ")

full_name = first_name + " " + last_name

print("\n========== STUDENT PROFILE ==========")

print("Full Name:", full_name)
print("Age:", age)
print("City:", city)
print("Favorite Hobby:", hobby)

print("Welcome to Python, " + full_name + "!")

print("=====================================")
